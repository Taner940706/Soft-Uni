from unittest import TestCase, main

from project.student import Student


class StudentTests(TestCase):
    def setUp(self) -> None:
        self.student = Student("John", {
            'Web Programming': ['note1', 'note2'],
            'Database': ['note3', 'note4']
        })

    def test_init_without_courses(self):
        name = "John"
        student = Student(name)

        self.assertEqual(name, student.name)
        self.assertEqual({}, student.courses)

    def test_init_with_courses(self):
        name = "John"
        courses = {
            'Web Programming': ['note1', 'note2'],
            'Database': ['note3', 'note4']
        }
        student = Student(name, courses)

        self.assertEqual(name, student.name)
        self.assertEqual(courses, student.courses)

    def test_enroll_with_already_enrolled_course(self):
        course = "Database"
        result = self.student.enroll(course, ["new note"])

        self.assertEqual("Course already added. Notes have been updated.", result)
        self.assertEqual(["note3, note4", 'new note'], self.student.courses[course])

    def test_enroll_new_course_with_note_add_Y(self):
        course = "Front-End"
        notes = ['FE1', 'FE2']

        result = self.student.enroll(course, notes, 'Y')
        self.assertEqual('Course and course notes have been added.', result)
        self.assertTrue(course in self.student.courses)
        self.assertEqual(notes, self.student.courses[course])

    def test_enroll_new_course_with_note_add_empty(self):
        course = "Front-End"
        notes = ['FE1', 'FE2']

        result = self.student.enroll(course, notes, '')
        self.assertEqual('Course and course notes have been added.', result)
        self.assertTrue(course in self.student.courses)
        self.assertEqual(notes, self.student.courses[course])

    def test_enroll_new_course_without_note(self):
        course = "Front-End"
        notes = ['FE1', 'FE2']

        result = self.student.enroll(course, notes, 'N')
        self.assertEqual('Course has been added.', result)
        self.assertTrue(course in self.student.courses)
        self.assertEqual([], self.student.courses[course])

    def test_add_notes__adds_notes_to_existing_course(self):
        course = "Web Programming"
        result = self.student.add_notes(course, 'extra_notes')
        self.assertEqual("Notes have been updated", result)
        self.assertEqual(['note1', 'note2', 'extra_notes'], self.student.courses[course])

    def test_add_notes__adds_notes_to_existing_course_raises(self):
        with self.assertRaises(Exception) as ex:
            result = self.student.add_notes("Invalid course", 'random course')

        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leave_course_ok(self):
        course = "Database"
        result = self.student.leave_course(course)

        self.assertEqual("Course has been removed", result)
        self.assertTrue(course not in self.student.courses)
        self.assertTrue(len(self.student.courses) > 0)

    def test_leave_course_raises(self):
        with self.assertRaises(Exception) as ex:
            result = self.student.leave_course("Invalid course")
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))




if __name__ == '__main__':
    main()
