import unittest

from project.mammal import Mammal


class MammalTests(unittest.TestCase):
    def setUp(self):
        self.mammal = Mammal("Lio", "Lion", "Wrrr")

    def test_make_sound(self):
        result = self.mammal.make_sound()
        expected_result = "Lio makes Wrrr"
        self.assertEqual(result, expected_result)

    def test_get_kingdom(self):
        result = self.mammal.get_kingdom()
        expected_result = "animals"
        self.assertEqual(result, expected_result)

    def test_info(self):
        result = self.mammal.info()
        expected_result = "Lio is of type Lion"
        self.assertEqual(result, expected_result)


if __name__ == "__main__":
    unittest.main()